# ntpdate-daemon
Simple script, that syncs system time every **n** seconds (default: 12h)  
(or `--oneshot` to sync on demand).  
**Requires `ntpdate` debian package.**

### Extras
Script for notify-daemon, that moves the daemon loop to the notify-daemon's job.
