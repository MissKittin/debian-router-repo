# apt-check
This package provides the `apt-check` script used in the misc and desktop-toolbox extras.  
Not mine, source lost (maybe from ubuntu forum or askubuntu).
