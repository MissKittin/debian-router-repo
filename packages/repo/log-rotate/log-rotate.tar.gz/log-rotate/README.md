# log-rotate
Extension for notify-daemon

### Configuration
log-rotate.sh: edit `etc/log-rotate.rc`  
notify-daemon: edit `log_rotate_every` value in `etc/notify-daemon/events.rc.d/log-rotate.rc`
