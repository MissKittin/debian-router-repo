<?php include $system['location_php'] . '/lib/login/login.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<title>Sample menu addon</title>
		<?php include $system['location_php'] . '/lib/htmlheaders.php'; ?>
	</head>
	<body>
		<h1>Sample Action</h1>
		You can close tab.
	</body>
</html>