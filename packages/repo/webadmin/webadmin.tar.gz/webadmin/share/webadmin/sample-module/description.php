<?php
	$name='Sample item';
	$category='Sample category';
?>