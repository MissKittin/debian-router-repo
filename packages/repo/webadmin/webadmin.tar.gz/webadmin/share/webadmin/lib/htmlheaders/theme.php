<?php /* theme header */ ?>
<link rel="stylesheet" type="text/css" href="<?php echo $system['location_html']; ?>/lib/themes/<?php echo $system['theme']; ?>">
