<?php if(!function_exists('prevent_direct')) include $system['location_php'] . '/lib/prevent-direct.php'; prevent_direct('header.php'); ?>
<h1><?php echo $system['title']; ?></h1>
