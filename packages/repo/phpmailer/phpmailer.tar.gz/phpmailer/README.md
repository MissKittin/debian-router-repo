# phpmailer
Simple script, that allows sending e-mail from command line.  
**Requires `wget` and shared hosting with PHP.**

### How to use
1) edit `etc/phpmailer.rc` and `phpmailer/settings.php`
2) upload `phpmailer` directory to shared hosting

### Extras
Sender method for notify-daemon: edit `sender-config.rc.d/phpmailer.rc`.
