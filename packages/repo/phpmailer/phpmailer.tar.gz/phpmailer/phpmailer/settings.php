<?php
	// phpmailer settings
	$user='username';
	$password='password';
?>