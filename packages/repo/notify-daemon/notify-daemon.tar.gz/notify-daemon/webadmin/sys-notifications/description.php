<?php
	$name='Notifications';
	$category='System';
?>