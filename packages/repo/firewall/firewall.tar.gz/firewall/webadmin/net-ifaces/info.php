<h1>Wired inputs</h1>
<table>
	<tr>
		<td style="font-weight: bold;">interfaceName</td><td>&#9472;&gt;</td><td>Interface description</td>
	</tr>
</table>