<?php
	$category='Power management';
?>