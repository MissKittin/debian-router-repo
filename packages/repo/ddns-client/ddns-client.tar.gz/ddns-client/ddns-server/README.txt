ddns server for ddns-client

Update values in settings.php and ddns-client.rc
and upload files in this directory to your hosting

Configuration: see settings.php

You can create 404.php in this dir to use custom error
or fake 404 page
Note: add at the top of the 404.php:
<?php http_response_code(404); ?>
