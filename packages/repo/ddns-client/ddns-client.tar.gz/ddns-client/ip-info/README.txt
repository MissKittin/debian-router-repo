If you don't have any service
that displays your public IP (like ipinfo.io),
upload this dir to your hosting
and configure ddns-client.
