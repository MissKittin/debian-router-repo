<?php
	$name='WiFi';
	$category='Network';
?>