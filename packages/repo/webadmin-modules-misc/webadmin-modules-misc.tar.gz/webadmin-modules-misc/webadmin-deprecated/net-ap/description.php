<?php
	$name='WiFi AP';
	$category='Network';
?>