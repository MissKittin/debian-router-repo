<?php
	$name='Devices';
	$category='Network';
?>