<?php
	$name='Storage & RAM';
	$category='System';
?>