<?php if(!function_exists('prevent_direct')) include $system['location_php'] . '/lib/prevent-direct.php'; prevent_direct('check-js.php'); ?>
<div>
	<span id="jawaskript" class="content_warning">&#9888; This application may not work until you enable javascript</span>
	<script>document.getElementById('jawaskript').style.display='none';</script>
</div>
