<?php
	$name='Wired';
	$category='Network';
?>