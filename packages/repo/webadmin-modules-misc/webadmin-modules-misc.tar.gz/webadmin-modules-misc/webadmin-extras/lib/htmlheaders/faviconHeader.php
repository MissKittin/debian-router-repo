<?php /* favicon headers */ ?>
<?php include $system['location_php'] . '/lib/favicon/favicon.php'; ?>