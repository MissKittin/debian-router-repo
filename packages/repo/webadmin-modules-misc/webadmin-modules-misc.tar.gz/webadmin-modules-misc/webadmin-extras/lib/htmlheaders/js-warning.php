<?php /* you have been warned */ ?>
<?php if($_SESSION['logged']) { ?><script>console.log("%cPlease do not paste any code here!", "color: #ff0000; font-size: 50px; font-weight: bold;");</script><?php } ?>
