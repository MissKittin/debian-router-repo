# logs2ram
Copies all `/var/log` to tmpfs and syncs them to disk on shutdown.
