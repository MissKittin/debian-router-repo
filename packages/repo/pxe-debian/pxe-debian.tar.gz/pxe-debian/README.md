# PXE debian
Toolbox for booting debian via PXE.  
Uses TFTP and SquashFS only (compressed OS resides in RAM).  
i686 version requires 256MB RAM (1GB recommended).  
**PXE debian uses sysvinit instead of systemd.**

### Warning
**This package is not for standalone debian installation!**  
**Package is designed for debian buster! May not work with another version.**

### Mastering and maintenance
See `README.md` in`dev-tools` directory.

# PXE NAS
See `pxe-nas-installer` package.
