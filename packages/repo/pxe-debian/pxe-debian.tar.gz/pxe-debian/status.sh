#!/bin/sh
# pxe-debian package
# dummy status script

echo 'This is a dummy status check'
echo 'Do not install this package manually'
exit 1
