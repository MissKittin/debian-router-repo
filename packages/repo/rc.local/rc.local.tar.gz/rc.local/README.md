# rc.local
Fragmentation of the `/etc/rc.local` for easier maintenance.  
Also provides command executing in background for faster boot.

### Configuration
`/usr/local/etc/rc.local.d`

### More info
See `/usr/local/etc/rc.local.d/README.TXT`
