# ACPI wake-up event toggler
Enables or disables ACPI wake-up events.  

Extras: script for rc.local package  
Configuration: `/usr/local/etc/toggle-wakeup-events.rc`  
Wake-up table: `/proc/acpi/wakeup`
