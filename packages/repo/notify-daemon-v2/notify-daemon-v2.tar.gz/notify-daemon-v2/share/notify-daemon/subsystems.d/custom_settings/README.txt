This subsystem imports user-defined settings only.
