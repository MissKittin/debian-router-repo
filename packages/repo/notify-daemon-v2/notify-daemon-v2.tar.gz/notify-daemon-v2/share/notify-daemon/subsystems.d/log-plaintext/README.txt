The notify-daemon logger (plaintext)
Allows the user to monitor the notify-daemon.
