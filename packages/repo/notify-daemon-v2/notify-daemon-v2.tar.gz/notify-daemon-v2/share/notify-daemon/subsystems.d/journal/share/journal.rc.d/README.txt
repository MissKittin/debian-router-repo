Here are journal default output parsers.
Add your parsers in etc/notify-daemon/journal.rc.d
This directory needs to be linked to the ${share_dir}

-----------------------------------
--- Dev details                 ---
-----------------------------------

|journal/subsystem.rc.d/parse.rc
|-$selected_parser.rc
