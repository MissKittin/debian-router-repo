The notify-daemon's notification manager
Without this you cannot send and receive any notifications.

This is the part of the notify-daemon core.
