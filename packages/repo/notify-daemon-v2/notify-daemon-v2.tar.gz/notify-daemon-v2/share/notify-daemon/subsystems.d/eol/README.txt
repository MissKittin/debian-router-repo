The notify-daemon killer
Restarts the notify-daemon, optionally compressing the log.
Works only in daemon mode.

This module is an extension for core subsystem.
