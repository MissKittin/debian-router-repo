The notify-daemon logger (syslog)
Allows the user to monitor the notify-daemon.
Uses logger for sending logs.
