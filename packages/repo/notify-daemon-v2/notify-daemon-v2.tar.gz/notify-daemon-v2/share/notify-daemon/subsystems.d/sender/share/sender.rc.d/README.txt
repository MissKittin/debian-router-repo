Here are send methods for sender subsystem.
Add your send methods in etc/notify-daemon/sender.rc.d
This directory needs to be linked to the ${share_dir}

-----------------------------------
--- Dev details                 ---
-----------------------------------

|sender/subsystem.rc
|-sender.rc.d/*
