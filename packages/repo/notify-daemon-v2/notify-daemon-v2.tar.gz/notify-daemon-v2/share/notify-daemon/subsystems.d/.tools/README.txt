The notify-daemon subsystems' tools.
Use these scripts to manage subsystems.
