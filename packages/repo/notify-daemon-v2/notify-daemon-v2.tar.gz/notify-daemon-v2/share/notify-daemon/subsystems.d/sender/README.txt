The notify-daemon sender
Without this you cannot send any notifications and keep them in journal.

This is part of the notify-daemon core.
