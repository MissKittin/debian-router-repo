# desktop-splashscreen
Set of wrappers for fbi image viewer.  
Add `splash` to kernel command line to enable.

### Configuration/Images
All configuration is in `/usr/local/etc/desktop-splashscreen`
*) `config.rc` enable/disable tweaks/hacks
*) `boot-splash.png`
*) `reboot-splash.png`
*) `shutdown-splash.png`
