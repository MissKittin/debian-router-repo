Put fancontrol-weather scrappers here
This files will be used if local mode is enabled
Remember to chmod 755 scrapper_name/scrapper
