# aptlists2ram
Copies all apt lists to tmpfs and syncs them to disk on shutdown.  
Enables `GzipIndexes` option.
