# localdns
Static `hosts` file builder for dnsmasq.  
You can easily assign DNS name to reserved IP (eg. isc-dhcp-server reservations).  

### Configuration
See `etc/hosts.d`

### Extras
* dnsmasq config
